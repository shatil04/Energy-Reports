"""
validation.py -- comparison of the dispatch model with observed 2025-2026 operating data.

Observations are BPDB/PGCB/Petrobangla figures as reported in the national press
(the BPDB daily-report archive is not machine-accessible). Each case drives the model
with the observed demand at the reported hour, the observed gas supply to power
(converted with the model's 5.6 MW per mmcfd), and plant outages or fuel-limited
outputs reported for that day.  All other units keep their planned availability
(Table 5).  The model output compared with observations is the shortfall at that hour.
"""
import numpy as np
import corridor_model as m

MW_PER_MMCFD = 5.6

# ---------------------------------------------------------------------------------
# 1. Gas-to-power conversion: (gas to power, mmcfd; observed gas-fired output, MW;
#    observed range low/high or None; date; source key)
# ---------------------------------------------------------------------------------
GAS_OBS = [
    (900, 5200, None, "first week of Apr 2026", "dailystar2026villages"),
    (800, 4500, None, "BPDB summer-2026 plan (upper bound)", "dailystar2026pdb"),
    (700, 3500, None, "3 Aug 2026", "dailystar2026aug3"),
    (700, 3589, None, "9 Aug 2026, 17:00", "observer2026aug"),
    (775, 3500, (3000, 4000), "mid-Aug 2026", "newnation2026aug"),
]

# ---------------------------------------------------------------------------------
# 2. Dated shortfall observations.
#    demand  = observed demand at the hour (MW) (= generation + shortfall where demand not given)
#    gas     = gas to power (mmcfd)
#    out     = reported reductions (MW) by model unit; 'HFO_cap' = reported fuel-limited oil output
# ---------------------------------------------------------------------------------
CASES = [
    dict(id="12 Jul 2025 (pre-crisis peak)", hour=20, demand=15510, obs=97, gas=998,
         out={}, src="fe2025jul"),
    dict(id="21 Apr 2026, 12:00", hour=12, demand=14069 + 1462, obs=1462, gas=900,
         out={"Coal": 660 + 612 + 430}, src="dailystar2026villages"),
    dict(id="26 Apr 2026, daytime", hour=13, demand=12300 + 2300, obs=2300, gas=900,
         out={"Coal": 1013 + 612 + 483, "Import": 750, "HFO_cap": 2750}, src="prothomalo2026apr26"),
    dict(id="2 Aug 2026, 17:00", hour=17, demand=15264, obs=15264 - 13201, gas=700,
         out={"Coal": 660, "HFO_cap": 3000}, src="dailystar2026aug3"),
    dict(id="9 Aug 2026, 15:00", hour=15, demand=16059, obs=3671, gas=700,
         out={"Coal": 1000, "Import": 785, "HFO_cap": 2000}, src="observer2026aug"),
    dict(id="9 Aug 2026, 17:00", hour=17, demand=13000 + 2967, obs=2967, gas=700,
         out={"Coal": 1000, "Import": 785, "HFO_cap": 2000}, src="observer2026aug"),
]
# evening-peak demand fully met, 27 Apr - 3 May 2026 (PGCB via BSS); gas assumed 900 mmcfd
NOSHED = [12793, 11475, 11036, 12614, 10462, 11092, 12745]


THERMAL = ("Coal", "HFO", "HSD", "Import")


def supply_at(p, hour, gas, out, planned_only=False, delta=0.0):
    """Available supply (MW) at an hour under observed upstream conditions.
    delta: unreported forced-outage derate applied to coal, oil and import units whose
    output was not itself reported (a fuel-limited oil output is used as reported)."""
    fl = {k: v[0] for k, v in m.fleet(p).items()}
    fl["DomGas"], fl["LNG"] = MW_PER_MMCFD * gas, 0.0
    capped = set()
    if not planned_only:
        for k, v in out.items():
            if k == "HFO_cap":
                fl["HFO"] = min(fl["HFO"], v)
                capped.add("HFO")
            else:
                fl[k] = max(0.0, fl[k] - v)
    for k in THERMAL:
        if k not in capped:
            fl[k] *= (1.0 - delta)
    return sum(fl.values()) + p["cap_solar"] * m.SOLAR_CF[hour], fl


def hindcast(p=None, delta=0.0):
    p = p or m.P()
    rows = []
    for c in CASES:
        s, _ = supply_at(p, c["hour"], c["gas"], c["out"], delta=delta)
        s0, _ = supply_at(p, c["hour"], c["gas"], c["out"], planned_only=True)
        rows.append(dict(c, supply=s, pred=max(0.0, c["demand"] - s), pred_planned=max(0.0, c["demand"] - s0)))
    noshed = []
    for d in NOSHED:
        s, _ = supply_at(p, 20, 900, {}, delta=delta)
        noshed.append(dict(demand=d, pred=max(0.0, d - s)))
    return rows, noshed


TRAIN = (1, 2)          # April 2026 cases: used to fit the derate
TEST = (3, 4, 5)        # August 2026 cases (LNG-terminal outage): independent test


def fit_delta(p=None, idx=TRAIN):
    """Least-squares fit of the unreported forced-outage derate on the training cases."""
    p = p or m.P()
    grid = np.linspace(0.0, 0.40, 401)
    sse = []
    for d in grid:
        rows, _ = hindcast(p, d)
        sse.append(sum((rows[i]["pred"] - rows[i]["obs"]) ** 2 for i in idx))
    return float(grid[int(np.argmin(sse))])


def gas_check():
    obs = np.array([g[1] for g in GAS_OBS], float)
    pred = np.array([MW_PER_MMCFD * g[0] for g in GAS_OBS], float)
    err = pred - obs
    return dict(points=[dict(mmcfd=g[0], obs=g[1], pred=MW_PER_MMCFD * g[0], date=g[3], src=g[4]) for g in GAS_OBS],
                MAE=float(np.mean(np.abs(err))), MAPE=float(np.mean(np.abs(err) / obs) * 100),
                bias=float(np.mean(err)))


def metrics(rows, key="pred"):
    o = np.array([r["obs"] for r in rows], float)
    q = np.array([r[key] for r in rows], float)
    e = q - o
    return dict(MAE=float(np.mean(np.abs(e))), RMSE=float(np.sqrt(np.mean(e ** 2))), bias=float(np.mean(e)),
                MAPE=float(np.mean(np.abs(e) / np.maximum(o, 1)) * 100) if len(o) else None,
                r=float(np.corrcoef(o, q)[0, 1]) if len(o) > 2 else None)


def hourly_21apr(p=None, delta=0.0):
    """Model hourly shortfall on 21 Apr 2026, demand shape scaled to the observed noon demand."""
    p = p or m.P()
    c = CASES[1]
    peak = c["demand"] / m.LOAD_SHAPE[c["hour"]]
    out = []
    for h in range(24):
        s, _ = supply_at(p, h, c["gas"], c["out"], delta=delta)
        out.append(max(0.0, peak * m.LOAD_SHAPE[h] - s))
    return np.array(out), peak


if __name__ == "__main__":
    print(gas_check())
    d = fit_delta()
    print("fitted derate on April cases:", d)
    for dd, lab in ((0.0, "reported outages only"), (d, "with fitted derate")):
        rows, ns = hindcast(delta=dd)
        print("---", lab)
        for r in rows:
            print(f"{r['id']:32s} D={r['demand']:6.0f} supply={r['supply']:7.0f} pred={r['pred']:6.0f} obs={r['obs']:6.0f}")
        print("train:", metrics([rows[i] for i in TRAIN]))
        print("test (Aug):", metrics([rows[i] for i in TEST]))
        print("all crisis:", metrics(rows[1:]))
        print("no-shed predicted:", [round(x["pred"]) for x in ns])
        h, pk = hourly_21apr(delta=dd)
        print("21 Apr hourly:", [round(x) for x in h])
    # leave-one-out over the five crisis cases
    loo = []
    for k in range(1, 6):
        dk = fit_delta(idx=tuple(i for i in range(1, 6) if i != k))
        rows, _ = hindcast(delta=dk)
        loo.append((CASES[k]["id"], round(dk, 3), round(rows[k]["pred"]), rows[k]["obs"]))
    print("LOO:", loo)
