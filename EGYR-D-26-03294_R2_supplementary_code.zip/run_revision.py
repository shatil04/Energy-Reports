"""
run_revision.py -- reproduces every number, table and figure in the revised manuscript.
Usage:  python run_revision.py            (about one minute on a laptop)
Outputs: figs/*.png and manuscript_numbers.json
"""
import json, os, time
import numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from scipy.stats import qmc, spearmanr
import corridor_model as m

os.makedirs("figs", exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "axes.titlesize": 10.5})
NAVY="#1F3864"; BLUE="#2E5496"; RED="#B0413E"; GREEN="#3C7A3C"; AMBER="#BF9000"; GREY="#4D4D4D"; PURPLE="#7B3F99"
OUT = {}; T0 = time.time()
def panels(axs, x=-0.12, y=1.04):
    for i, a in enumerate(np.ravel(axs)):
        a.text(x, y, f"({chr(97 + i)})", transform=a.transAxes, fontsize=11, fontweight="bold", va="bottom")


def save(fig, name):
    fig.tight_layout(); fig.savefig(f"figs/{name}.png", dpi=200, bbox_inches="tight"); plt.close(fig)
p = m.P()
DUR = [7, 14, 30, 45, 60, 90]

# =====================================================================================
# 0. Calibration against the 2026 episode
# =====================================================================================
ref = m.dispatch_day(p, None, 0, return_detail=True)
gas = m.dispatch_day(p, "Hormuz", 15, return_detail=True)
oil = m.dispatch_day(p, "Hormuz", 40, return_detail=True)
OUT["calibration"] = dict(ref_peak_shed_MW=float(ref["unserved"].max()), ref_daily_EUE_MWh=float(ref["unserved"].sum()),
                          gas_phase_peak_shed_MW=float(gas["unserved"].max()), gas_phase_EUE_MWh=float(gas["unserved"].sum()),
                          gas_phase_shed_hours=int((gas["unserved"] > 1).sum()),
                          oil_phase_peak_shed_MW=float(oil["unserved"].max()), oil_phase_EUE_MWh=float(oil["unserved"].sum()),
                          oil_phase_shed_hours=int((oil["unserved"] > 1).sum()))
OUT["lp_equivalence"] = [dict(day=t, merit=a, lp=b) for t, a, b in m.verify_lp_equivalence(p)]

# =====================================================================================
# 1. Exposure matrix and availability paths
# =====================================================================================
E = m.exposure(p); cols = ["Hormuz","GulfOfOman","Atlantic","Malacca_Sunda","OtherCoal","OtherOil","Transmission"]
mat = np.array([[m.at_risk(p, f, c) for c in cols] for f in m.FUELS])
dom = np.array([1.0 - E[f][0] for f in m.FUELS])            # domestic / not imported (not at risk)
mat = np.column_stack([mat, dom]); cols = cols + ["Domestic"]
assert np.allclose(mat.sum(axis=1), 1.0)
OUT["exposure"] = {f: {c: round(float(mat[i, j]), 3) for j, c in enumerate(cols)} | {"buffer": E[f][2]} for i, f in enumerate(m.FUELS)}
fig, ax = plt.subplots(figsize=(8.8, 4.0))
im = ax.imshow(mat, cmap="Reds", vmin=0, vmax=1, aspect="auto")
ax.set_xticks(range(len(cols))); ax.set_xticklabels(["Hormuz","Gulf of\nOman","Atlantic","Malacca/\nSunda","Other coal\nroutes","Other oil\nroutes","Trans-\nmission","Domestic\n(no import)"], fontsize=8.2)
ax.axvline(len(cols) - 1.5, color="k", lw=1)
ax.set_yticks(range(len(m.FUELS))); ax.set_yticklabels(["Domestic gas","LNG gas","Coal","HFO","HSD","Imported elec.","Hydro","Wind"], fontsize=8.5)
for i in range(mat.shape[0]):
    for j in range(mat.shape[1]):
        if mat[i, j] > 0: ax.text(j, i, f"{mat[i,j]:.2f}", ha="center", va="center", fontsize=8, color="white" if mat[i,j] > 0.5 else "black")
for i, f in enumerate(m.FUELS):
    ax.text(len(cols) - 0.35, i, f"  {E[f][2]:.0f} d" if E[f][0] > 0 and f != "Import" else ("  0 d" if f == "Import" else "  –"), va="center", fontsize=8, color=NAVY)
ax.text(len(cols) - 0.35, -0.85, "  buffer", fontsize=8, color=NAVY)
fig.colorbar(im, ax=ax, fraction=0.03, pad=0.12, label="Share of the fuel's supply")
ax.set_title("Exposure matrix: share of each fuel's supply by route (rows sum to 1)", color=NAVY, fontweight="bold")
save(fig, "fig_matrix")

days = np.arange(0, 91)
fig, ax = plt.subplots(figsize=(7.4, 4.0))
for f, cl, lab in [("LNG", BLUE, "LNG gas"), ("HFO", AMBER, "HFO"), ("HSD", PURPLE, "HSD"), ("Coal", GREY, "Coal"), ("Import", GREEN, "Imported electricity")]:
    ax.plot(days, [100*m.availability(p, f, "Hormuz", d) for d in days], lw=2, color=cl, label=lab)
ax.set_xlabel("Day of Strait of Hormuz closure"); ax.set_ylabel("Fuel supply available (%)")
ax.set_ylim(0, 105); ax.grid(alpha=.3); ax.legend(fontsize=8, loc="lower left")
ax.set_title("Stock buffers stage a Hormuz closure in time (Model A, tau = 7 d)", color=NAVY, fontweight="bold")
save(fig, "fig_paths")

# =====================================================================================
# 2. Single-fuel bias (Model A) -- attributable unserved energy
# =====================================================================================
refday = m.dispatch_day(p, None, 0)
bias_tab = []
for D in DUR:
    B, mm, um, us = m.bias(p, D)
    bias_tab.append(dict(D=D, total_multi=(um + D*refday)/1e3, total_single=(us + D*refday)/1e3,
                         dU_multi=um/1e3, dU_single=us/1e3, B=B*100, m=mm*100))
OUT["bias_modelA"] = bias_tab
OUT["ref_daily_EUE_MWh"] = refday
new_p = [m.dispatch_day(p, "Hormuz", d) - refday for d in days]
old_p = [m.dispatch_day(p, "Hormuz", d, lng_only=True) - refday for d in days]
fig, ax = plt.subplots(figsize=(7.4, 4.0))
ax.plot(days, np.array(new_p)/1e3, lw=2, color=RED, label="Corridor-resolved (all exposed fuels)")
ax.plot(days, np.array(old_p)/1e3, lw=2, ls="--", color=BLUE, label="LNG-only (single-fuel counterfactual)")
ax.fill_between(days, np.array(old_p)/1e3, np.array(new_p)/1e3, color=RED, alpha=.15)
for x, lab, cl in [(p["buf_lng"], "LNG buffer\nexhausted", BLUE), (p["buf_hsd"], "oil buffers\nexhausted", AMBER)]:
    ax.axvline(x, ls=":", color=cl, lw=1); ax.text(x + 1, max(new_p)/1e3*0.8, lab, fontsize=7.5, color=cl)
ax.set_xlabel("Day of closure"); ax.set_ylabel("Closure-attributable unserved energy (GWh/day)")
ax.legend(fontsize=8, loc="center right"); ax.grid(alpha=.3)
ax.set_title("A single-fuel model misses the oil phase of a sustained closure", color=NAVY, fontweight="bold")
save(fig, "fig_newold")

# =====================================================================================
# 3. Corridor comparison
# =====================================================================================
corr_list = [("Hormuz","Strait of Hormuz"), ("Malacca_Sunda","Malacca/Sunda straits"), ("Transmission","India interconnection"),
             ("OtherOil","Other oil routes"), ("GulfOfOman","Gulf of Oman"), ("Atlantic","Atlantic LNG")]
corr_res = {c: dict(d30=m.attributable(p, c, 30)/1e3, d60=m.attributable(p, c, 60)/1e3, d90=m.attributable(p, c, 90)/1e3) for c, _ in corr_list}
OUT["corridors_modelA"] = corr_res
fig, ax = plt.subplots(figsize=(7.4, 3.8))
y = np.arange(len(corr_list)); w = .38
ax.barh(y - w/2, [corr_res[c]["d60"] for c, _ in corr_list], w, color=RED, label="60-day closure")
ax.barh(y + w/2, [corr_res[c]["d90"] for c, _ in corr_list], w, color=NAVY, label="90-day closure")
ax.set_yticks(y); ax.set_yticklabels([l for _, l in corr_list]); ax.invert_yaxis()
ax.set_xlabel("Closure-attributable unserved energy (GWh)"); ax.legend(fontsize=8); ax.grid(axis="x", alpha=.3)
ax.set_title("Two maritime chokepoints of comparable consequence (Model A)", color=NAVY, fontweight="bold")
save(fig, "fig_corridors")

# =====================================================================================
# 4. Formulation robustness: Model A vs explicit-inventory Model B variants
# =====================================================================================
form = {}
for c in ["Hormuz", "Malacca_Sunda"]:
    for D in [30, 60, 90]:
        row = dict(A=m.attributable(p, c, D)/1e3,
                   B_myopic_fixed=m.inventory_myopic_attributable(p, c, D, supply="fixed")[0]/1e3,
                   B_myopic_flex=m.inventory_myopic_attributable(p, c, D, supply="flexible")[0]/1e3,
                   B_foresight_fixed=m.inventory_attributable(p, c, D, supply="fixed")[0]/1e3,
                   B_foresight_flex=m.inventory_attributable(p, c, D, supply="flexible")[0]/1e3)
        if c == "Hormuz":
            row.update(A_single=m.attributable(p, c, D, lng_only=True)/1e3,
                       B_myopic_fixed_single=m.inventory_myopic_attributable(p, c, D, lng_only=True, supply="fixed")[0]/1e3,
                       B_myopic_flex_single=m.inventory_myopic_attributable(p, c, D, lng_only=True, supply="flexible")[0]/1e3)
        form[f"{c}_{D}"] = row
OUT["formulations"] = form
_, dA = None, [m.dispatch_day(p, "Hormuz", d) - refday for d in range(90)]
_, dBf = m.inventory_myopic_attributable(p, "Hormuz", 90, supply="fixed")
_, dBx = m.inventory_myopic_attributable(p, "Hormuz", 90, supply="flexible")
_, dBp = m.inventory_attributable(p, "Hormuz", 90, supply="flexible")
fig, ax = plt.subplots(figsize=(7.4, 4.0))
cum = lambda a: np.cumsum(a)/1e3
ax.plot(range(1, 91), cum(np.array(dA)), color=RED, lw=2.2, label="Model A: availability cap (baseline)")
ax.plot(range(1, 91), cum(dBf - refday), color=NAVY, lw=1.8, ls="--", label="Model B: inventory, fixed residual supply")
ax.plot(range(1, 91), cum(dBx - refday), color=GREEN, lw=1.8, ls="-.", label="Model B: inventory, flexible residual supply")
_, dMal_A = None, [m.dispatch_day(p, "Malacca_Sunda", d) - refday for d in range(90)]
_, dMal_B = m.inventory_myopic_attributable(p, "Malacca_Sunda", 90)
ax.plot(range(1, 91), cum(np.array(dMal_A)), color=GREY, lw=1.6, label="Malacca/Sunda closure, Model A")
ax.plot(range(1, 91), cum(dMal_B - refday), color=GREY, lw=1.4, ls=":", label="Malacca/Sunda closure, Model B (myopic)")
for D in (60, 90):
    ax.plot([D], [form[f"Malacca_Sunda_{D}"]["B_foresight_fixed"]], "v", color=AMBER, ms=7,
            label="Malacca/Sunda, Model B with foresight rationing" if D == 60 else None)
ax.set_xlabel("Closure duration D (days)"); ax.set_ylabel("Cumulative attributable unserved energy (GWh)")
ax.legend(fontsize=7.3, loc="upper left"); ax.grid(alpha=.3)
ax.set_title("Cumulative shortfall under alternative fuel-stock formulations", color=NAVY, fontweight="bold")
save(fig, "fig_formulations")

# =====================================================================================
# 5. Depletion-period (tau) sensitivity
# =====================================================================================
tau_res = []
def _merit(pp, caps):
    order = sorted(caps, key=lambda k: caps[k][1]); resid = np.maximum(0, m.LOAD_SHAPE*pp["peak"] - pp["cap_solar"]*m.SOLAR_CF)
    for k in order: resid = resid - np.minimum(caps[k][0], resid)
    return float(resid.sum())
for tau in [0, 3, 7, 14, 21, "fuel"]:
    if tau == "fuel":
        # fuel-specific spread: tau_f = beta_f / 2  (LNG 3 d, HSD 11 d, HFO 12.5 d, coal 17.5 d)
        def ae(pp, c, D, lo=False):
            tot = 0.0
            for t in range(D):
                fl = m.fleet(pp); caps = {}
                for f, (mw, mc) in fl.items():
                    a = m.availability(pp, f, c, t, tau=m.exposure(pp)[f][2]/2) if (not lo or f == "LNG") else 1.0
                    caps[f] = (mw*a, mc)
                tot += _merit(pp, caps)
            return tot - D*refday
        um60 = ae(p, "Hormuz", 60); us60 = ae(p, "Hormuz", 60, True); um30 = ae(p, "Hormuz", 30); us30 = ae(p, "Hormuz", 30, True)
        mal60 = ae(p, "Malacca_Sunda", 60)
    else:
        um60 = m.attributable(p, "Hormuz", 60, tau=tau); us60 = m.attributable(p, "Hormuz", 60, lng_only=True, tau=tau)
        um30 = m.attributable(p, "Hormuz", 30, tau=tau); us30 = m.attributable(p, "Hormuz", 30, lng_only=True, tau=tau)
        mal60 = m.attributable(p, "Malacca_Sunda", 60, tau=tau)
    tau_res.append(dict(tau=tau, dU60=um60/1e3, B30=(um30-us30)/us30*100 if us30 > 0 else None, B60=(um60-us60)/us60*100, mal60=mal60/1e3, ratio=mal60/um60))
OUT["tau"] = tau_res


# =====================================================================================
# 6. One-at-a-time sensitivity (tornado) on estimated parameters
# =====================================================================================
def metrics(pp):
    um60 = m.attributable(pp, "Hormuz", 60); us60 = m.attributable(pp, "Hormuz", 60, lng_only=True)
    um30 = m.attributable(pp, "Hormuz", 30); us30 = m.attributable(pp, "Hormuz", 30, lng_only=True)
    mal = m.attributable(pp, "Malacca_Sunda", 60)
    return dict(dU60=um60/1e3, B60=(um60-us60)/us60*100 if us60 > 0 else np.nan,
                B30=(um30-us30)/us30*100 if us30 > 0 else np.nan, mal60=mal/1e3, ratio=mal/um60 if um60 > 0 else np.nan)
base_m = metrics(p); OUT["base_metrics"] = base_m
oat_keys = ["buf_lng","buf_coal","buf_hfo","buf_hsd","lng_hormuz","coal_malacca","oil_hormuz","tau",
            "cap_domgas","cap_lng","af_imp","af_coal","af_hfo","peak","voll_bdt","mc_lng","mc_hfo","mc_coal"]
labels = dict(buf_lng="LNG buffer", buf_coal="Coal buffer", buf_hfo="HFO buffer", buf_hsd="HSD buffer",
              lng_hormuz="LNG share via Hormuz", coal_malacca="Coal share via Malacca/Sunda", oil_hormuz="Oil share via Hormuz",
              tau="Depletion period tau", cap_domgas="Domestic gas output", cap_lng="LNG-backed gas output",
              af_imp="Import availability", af_coal="Coal availability", af_hfo="HFO availability", peak="Peak demand",
              voll_bdt="Value of lost load", mc_lng="LNG marginal cost", mc_hfo="HFO marginal cost", mc_coal="Coal marginal cost")
oat = {}
for k in oat_keys:
    lo, hi = m.PARAMS[k][4]
    oat[k] = dict(lo=lo, hi=hi, at_lo=metrics(m.P({k: lo})), at_hi=metrics(m.P({k: hi})))
OUT["oat"] = oat
fig, axs = plt.subplots(1, 2, figsize=(10.5, 5.0), sharey=True)
order = sorted(oat_keys, key=lambda k: -abs(oat[k]["at_hi"]["dU60"] - oat[k]["at_lo"]["dU60"]))
yy = np.arange(len(order))
for ax, key, xl, basev in [(axs[0], "dU60", "Attributable unserved energy, 60-day Hormuz closure (GWh)", base_m["dU60"]),
                           (axs[1], "B60", "Single-fuel understatement B(60) (%)", base_m["B60"])]:
    for i, k in enumerate(order):
        lo_v, hi_v = oat[k]["at_lo"][key], oat[k]["at_hi"][key]
        ax.barh(i, lo_v - basev, left=basev, color=BLUE, height=.6)
        ax.barh(i, hi_v - basev, left=basev, color=RED, height=.6)
    ax.axvline(basev, color="k", lw=1); ax.set_xlabel(xl, fontsize=8.5); ax.grid(axis="x", alpha=.3)
axs[0].set_yticks(yy); axs[0].set_yticklabels([labels[k] for k in order], fontsize=8); axs[0].invert_yaxis()
from matplotlib.patches import Patch
axs[0].legend(handles=[Patch(color=BLUE, label="parameter at low end of range"), Patch(color=RED, label="parameter at high end of range")], fontsize=7.5, loc="lower right")
panels(axs, x=-0.02)
fig.suptitle("One-at-a-time sensitivity over the documented parameter ranges", color=NAVY, fontweight="bold", fontsize=10.5)
save(fig, "fig_tornado")

# =====================================================================================
# 7. Global uncertainty: Latin hypercube over all estimated parameters jointly
# =====================================================================================
glob_keys = [k for k in oat_keys if k not in ("voll_bdt", "mc_lng", "mc_hfo", "mc_coal")] + ["af_hsd"]
N = 1500
sampler = qmc.LatinHypercube(d=len(glob_keys), seed=7); U = sampler.random(N)
res = []
for row in U:
    ov = {k: m.PARAMS[k][4][0] + row[i]*(m.PARAMS[k][4][1] - m.PARAMS[k][4][0]) for i, k in enumerate(glob_keys)}
    res.append(metrics(m.P(ov)))
R = {k: np.array([r[k] for r in res], float) for k in res[0]}
def pct(a, q): a = a[~np.isnan(a)]; return float(np.percentile(a, q))
OUT["montecarlo"] = dict(N=N,
    dU60=[pct(R["dU60"], q) for q in (5, 50, 95)], B30=[pct(R["B30"], q) for q in (5, 50, 95)],
    B60=[pct(R["B60"], q) for q in (5, 50, 95)], ratio=[pct(R["ratio"], q) for q in (5, 50, 95)],
    P_B60_gt_100=float(np.nanmean(R["B60"] > 100)), P_B60_gt_0=float(np.nanmean(R["B60"] > 0)),
    P_ratio_gt_05=float(np.nanmean(R["ratio"] > 0.5)), P_B30_eq_0=float(np.nanmean(np.nan_to_num(R["B30"], nan=0) < 1)),
    spearman_B60={k: float(spearmanr(U[:, i], R["B60"], nan_policy="omit")[0]) for i, k in enumerate(glob_keys)},
    spearman_dU60={k: float(spearmanr(U[:, i], R["dU60"], nan_policy="omit")[0]) for i, k in enumerate(glob_keys)},
    spearman_ratio={k: float(spearmanr(U[:, i], R["ratio"], nan_policy="omit")[0]) for i, k in enumerate(glob_keys)})
fig, axs = plt.subplots(1, 3, figsize=(11, 3.4))
for ax, key, xl, cl in [(axs[0], "dU60", "Attributable EUE, 60-d Hormuz (GWh)", RED), (axs[1], "B60", "Single-fuel understatement B(60) (%)", NAVY),
                        (axs[2], "ratio", "Malacca / Hormuz consequence (60 d)", GREEN)]:
    full = R[key][~np.isnan(R[key])]; a = full[full <= np.percentile(full, 99)]; ax.hist(a, bins=40, color=cl, alpha=.85)
    ax.axvline(np.median(full), color="k", lw=1.2, label="median")
    for q in (5, 95):
        ax.axvline(np.percentile(full, q), color="k", lw=1, ls="--", label="5th / 95th percentile" if q == 5 else None)
    ax.set_xlabel(xl, fontsize=8.5); ax.grid(alpha=.3)
axs[0].set_ylabel("Number of draws"); axs[0].legend(fontsize=7.5); panels(axs)
fig.suptitle(f"Joint uncertainty over all estimated parameters (Latin hypercube, N = {N}; top 1% of draws not shown)", color=NAVY, fontweight="bold", fontsize=10.5)
save(fig, "fig_montecarlo")

# =====================================================================================
# 8. Rerouting sensitivity
# =====================================================================================
rr = {}
for theta, lag in [(0.3, 14), (0.5, 14), (0.5, 7)]:
    rp = dict(fuels=["LNG", "HFO", "HSD"], theta=theta, lag=lag)
    um = m.attributable(p, "Hormuz", 60, reroute=rp); us = m.attributable(p, "Hormuz", 60, lng_only=True, reroute=rp)
    rr[f"theta{theta}_lag{lag}"] = dict(dU60=um/1e3, B60=(um-us)/us*100 if us > 0 else None)
OUT["reroute"] = rr

# =====================================================================================
# 9. Storage: explicit-SOC LP by closure phase, sizing, economics, alternative levers
# =====================================================================================
Egrid = np.arange(0, 20001, 1000)
st = {}
for lab, t in [("gas", 15), ("oil", 40)]:
    for S in [0, 3000, 6000]:
        st[f"{lab}_S{S}"] = [m.day_lp_storage(p, "Hormuz", t, float(Ev), extra_solar=S)[0] for Ev in Egrid]
OUT["storage_sweep"] = dict(E=Egrid.tolist(), **st)
fig, axs = plt.subplots(1, 2, figsize=(10.5, 3.8), sharey=False)
for ax, lab, ttl in [(axs[0], "gas", "Gas phase (day 15): LNG lost, oil intact"), (axs[1], "oil", "Oil phase (day 40): LNG and oil lost")]:
    for S, cl in [(0, NAVY), (3000, BLUE), (6000, GREEN)]:
        ax.plot(Egrid/1e3, np.array(st[f"{lab}_S{S}"])/1e3, "-o", ms=3, color=cl, label=f"+{S/1e3:.0f} GW new solar")
    ax.axhline(m.dispatch_day(p, None, 0)/1e3, color=GREY, ls=":", lw=1.2, label="no closure, no storage")
    ax.set_xlabel("Battery energy E (GWh, beginning of life), power E/4"); ax.set_title(ttl, color=NAVY, fontweight="bold", fontsize=9.5); ax.grid(alpha=.3)
    ax.set_ylim(bottom=0)
axs[0].set_ylabel("Total daily unserved energy (GWh)"); axs[0].legend(fontsize=8); panels(axs)
save(fig, "fig_storage_sweep")

# 24-h dispatch in the gas phase with and without an 8 GWh battery
_, det8 = m.day_lp_storage(p, "Hormuz", 15, 8000.0)
d15 = m.dispatch_day(p, "Hormuz", 15, return_detail=True)
fig, axs = plt.subplots(1, 2, figsize=(10.5, 3.8), sharey=True)
hrs = np.arange(24)
stack_names = ["Hydro","Wind","DomGas","Import","Coal","LNG","HFO","HSD"]
colors = ["#6FA8DC","#93C47D","#1F3864","#3C7A3C","#4D4D4D","#2E5496","#BF9000","#7B3F99"]
for ax, ttl in [(axs[0], "No storage"), (axs[1], "With 8 GWh / 2 GW battery")]:
    bottom = np.zeros(24)
    ax.fill_between(hrs, 0, d15["solar"], color="#F1C232", step="mid", label="Solar")
    bottom = d15["solar"].copy()
    for n, cl in zip(stack_names, colors):
        g = d15["gen"][n]; ax.fill_between(hrs, bottom, bottom+g, color=cl, step="mid", label=n); bottom = bottom + g
    if ttl.startswith("With"):
        ax.fill_between(hrs, bottom, bottom + det8["dis"], color="#E06666", step="mid", label="Battery discharge")
        bottom = bottom + det8["dis"]
        unserved = det8["u"]
    else:
        unserved = d15["unserved"]
    ax.fill_between(hrs, bottom, bottom + unserved, facecolor="none", edgecolor=RED, hatch="////", lw=0, step="mid", label="Unserved (load shed)")
    ax.plot(hrs, d15["demand"], color=RED, lw=2, label="Demand")
    ax.set_xlabel("Hour of day"); ax.set_title(ttl, color=NAVY, fontweight="bold", fontsize=9.5); ax.set_xlim(0, 23)
    if ttl.startswith("With"):
        a2 = ax.twinx(); a2.plot(hrs, det8["soc"]/1e3, color="k", lw=1.3, ls=":", label="State of charge (GWh, right axis)")
        a2.set_ylabel("Battery state of charge (GWh)"); a2.set_ylim(0, 9)
        h2, l2 = a2.get_legend_handles_labels()
axs[0].set_ylabel("Generation and demand (MW)"); panels(axs)
h_, l_ = axs[1].get_legend_handles_labels()
fig.legend(h_ + h2, l_ + l2, fontsize=7.5, ncol=6, loc="lower center", bbox_to_anchor=(0.5, -0.12))
fig.suptitle("Gas phase of a Hormuz closure: the shortfall falls on the solar-free evening peak", color=NAVY, fontweight="bold", fontsize=10.5)
save(fig, "fig_24h")

# economics: annualised cost vs avoided unserved energy in gas-phase crisis days
def crf(r, n): return r*(1+r)**n/((1+r)**n-1)
ECON = dict(capex=350.0, om=0.025, r=0.08, life=12, voll=900.0, fade=0.20, rte=0.88, pr=4.0)
def resid_curve(rte, pr, usable):
    return np.array([m.day_lp_storage(p, "Hormuz", 15, float(Ev), P_ratio=pr, eta_rt=rte, usable=usable)[0] for Ev in Egrid])
def econ(ec, curve):
    ann = (crf(ec["r"], ec["life"]) + ec["om"]) * ec["capex"] * 1000 * Egrid          # USD/yr
    base = curve[0]
    out = {}
    for Nd in [15, 30, 60, 90]:
        tot = ann + Nd * curve * ec["voll"]; out[Nd] = float(Egrid[int(np.argmin(tot))])
    avoided8 = base - curve[list(Egrid).index(8000)]
    be8 = ann[list(Egrid).index(8000)] / (avoided8 * ec["voll"])
    return out, be8, ann
curve0 = resid_curve(ECON["rte"], ECON["pr"], 1 - ECON["fade"]/2)
opt0, be0, ann0 = econ(ECON, curve0)
OUT["storage_econ_base"] = dict(opt=opt0, breakeven8=be0, crf=crf(ECON["r"], ECON["life"]), params=ECON)
# break-even robustness
cases = {}
for k, vals in dict(capex=[200, 450], voll=[500, 2000], r=[0.06, 0.12], life=[10, 15], fade=[0.0, 0.30]).items():
    for v in vals:
        ec = dict(ECON); ec[k] = v
        cur = curve0 if k != "fade" else resid_curve(ec["rte"], ec["pr"], 1 - ec["fade"]/2)
        cases[f"{k}={v}"] = econ(ec, cur)[1]
for rte in [0.85, 0.92]:
    ec = dict(ECON); ec["rte"] = rte; cases[f"rte={rte}"] = econ(ec, resid_curve(rte, ECON["pr"], 1-ECON["fade"]/2))[1]
for pr in [2.0, 6.0]:
    ec = dict(ECON); ec["pr"] = pr; cases[f"duration={pr}h"] = econ(ec, resid_curve(ECON["rte"], pr, 1-ECON["fade"]/2))[1]
OUT["storage_breakeven_cases"] = cases
# joint Monte Carlo on economic parameters (curve fixed at base technical parameters)
rng = np.random.default_rng(3); be = []
for _ in range(5000):
    ec = dict(ECON, capex=rng.uniform(200, 450), voll=rng.uniform(500, 2000), r=rng.uniform(.06, .12), life=rng.uniform(10, 15))
    be.append(econ(ec, curve0)[1])
be = np.array(be); OUT["storage_breakeven_mc"] = [float(np.percentile(be, q)) for q in (5, 50, 95)]
fig, axs = plt.subplots(1, 2, figsize=(10.5, 3.8))
ds = np.arange(5, 181, 5); eo = []
for Nd in ds:
    tot = ann0 + Nd * curve0 * ECON["voll"]; eo.append(Egrid[int(np.argmin(tot))]/1e3)
axs[0].step(ds, eo, where="post", color=NAVY, lw=2)
axs[0].set_xlabel("Gas-phase crisis days per year"); axs[0].set_ylabel("Cost-optimal battery energy (GWh)")
axs[0].set_title("Least-cost storage rises with crisis frequency", color=NAVY, fontweight="bold", fontsize=9.5); axs[0].grid(alpha=.3)
names_ = list(cases.keys()); vals_ = [cases[k] for k in names_]
axs[1].barh(range(len(names_)), vals_, color=[RED if v > be0 else BLUE for v in vals_]); axs[1].axvline(be0, color="k", lw=1)
axs[1].set_yticks(range(len(names_))); axs[1].set_yticklabels(names_, fontsize=7.5); axs[1].invert_yaxis()
axs[1].set_xlabel("Break-even crisis days/yr, 8 GWh battery"); axs[1].grid(axis="x", alpha=.3)
axs[1].set_title(f"Break-even robustness (base {be0:.0f} d/yr)", color=NAVY, fontweight="bold", fontsize=9.5)
panels(axs, x=-0.14)
save(fig, "fig_leastcost")
# worked example of the break-even arithmetic (Section 6.6)
i8 = list(Egrid).index(8000)
OUT["storage_worked"] = dict(crf=crf(ECON["r"], ECON["life"]), ann_per_kWh=(crf(ECON["r"], ECON["life"]) + ECON["om"]) * ECON["capex"],
                             ann_8GWh_MUSD=float(ann0[i8]) / 1e6, base_gas_day_MWh=float(curve0[0]), resid_8GWh_MWh=float(curve0[i8]),
                             avoided_MWh=float(curve0[0] - curve0[i8]), value_per_day_MUSD=float((curve0[0] - curve0[i8]) * ECON["voll"]) / 1e6,
                             breakeven=float(be0), voll_bdt_per_kWh=p["voll_bdt"], bdt_per_usd=122.0)

# alternative resilience levers over a 60-day Hormuz closure.  Every measure is evaluated on
# one basis: TOTAL unserved energy over the 60 days of closure (Model A), so measures that also
# relieve the no-closure shortfall (storage, demand response) are compared like for like.
base60 = m.cumulative_eue(p, "Hormuz", 60)
def with_storage(E, S=0.0):
    return sum(m.day_lp_storage(p, "Hormuz", t, E, extra_solar=S, usable=1-ECON["fade"]/2)[0] for t in range(60))
levers = {
    "LNG buffer +7 d": m.cumulative_eue(m.P({"buf_lng": p["buf_lng"]+7}), "Hormuz", 60),
    "Oil buffers +14 d": m.cumulative_eue(m.P({"buf_hfo": p["buf_hfo"]+14, "buf_hsd": p["buf_hsd"]+14}), "Hormuz", 60),
    "Rerouting: 50% of lost LNG/oil after 14 d": m.cumulative_eue(p, "Hormuz", 60, reroute=dict(fuels=["LNG","HFO","HSD"], theta=.5, lag=14)),
    "Evening demand response 1 GW": m.cumulative_eue(p, "Hormuz", 60, dr_evening=1000.0),
    "Battery 8 GWh / 2 GW": with_storage(8000.0),
    "Solar +3 GW": m.cumulative_eue(p, "Hormuz", 60, extra_solar=3000.0),
    "Solar +3 GW with 8 GWh battery": with_storage(8000.0, 3000.0),
    "Solar +6 GW with 12 GWh battery": with_storage(12000.0, 6000.0),
}
OUT["levers_60d_total"] = dict(base=base60/1e3, **{k: v/1e3 for k, v in levers.items()})

# =====================================================================================
# 10. Diversity indices (LNG routing harmonised with the exposure matrix) and four-A index
# =====================================================================================
sup = dict(Qatar=0.363, Oman=0.191, Spot=0.446)
f_spot = (p["lng_hormuz"] - 0.363) / 0.446
corr = dict(Hormuz=0.363 + 0.446*f_spot, GulfOfOman=0.191, Atlantic=0.446*(1 - f_spot))
fuelmix = dict(Gas=43.97, Coal=19.97, HFO=19.83, Imported=9.48, Renewable=4.62, HSD=2.13)
bins = [0.363, 0.446*f_spot, 0.191, 0.446*(1-f_spot)]; labs = ["H", "H", "O", "A"]
Delta = sum(bins[i]*bins[j] for i in range(4) for j in range(4) if i != j and labs[i] != labs[j])
fs = np.linspace(.3, .9, 13)
OUT["diversity"] = dict(f_spot=f_spot, corridors=corr,
    fuel=dict(HHI=m.hhi(list(fuelmix.values())), H=m.shannon(list(fuelmix.values())), Hn=m.shannon(list(fuelmix.values()))/np.log(6)),
    suppliers=dict(HHI=m.hhi(list(sup.values())), H=m.shannon(list(sup.values())), Hn=m.shannon(list(sup.values()))/np.log(3), Neff=1/m.hhi(list(sup.values()))),
    corr=dict(HHI=m.hhi(list(corr.values())), H=m.shannon(list(corr.values())), Hn=m.shannon(list(corr.values()))/np.log(3), Neff=1/m.hhi(list(corr.values()))),
    Delta=Delta, HHI_range=[min(m.hhi([.363+.446*f, .191, .446*(1-f)]) for f in fs), max(m.hhi([.363+.446*f, .191, .446*(1-f)]) for f in fs)])
fig, (a1, a2) = plt.subplots(1, 2, figsize=(9.5, 3.5))
a1.bar(["Hormuz", "Gulf of Oman", "Atlantic/other"], list(corr.values()), color=[RED, BLUE, GREEN])
for i, v in enumerate(corr.values()): a1.text(i, v + .01, f"{v:.2f}", ha="center", fontsize=8)
a1.set_ylabel("Share of LNG supply"); a1.set_title("Physical loading corridors, 2025", color=NAVY, fontweight="bold", fontsize=9.5)
a2.plot(fs*100, [m.hhi([.363+.446*f, .191, .446*(1-f)]) for f in fs], "-o", ms=3, color=NAVY)
a2.axvline(f_spot*100, color=RED, ls=":", lw=1); a2.text(f_spot*100+1, .40, "baseline", color=RED, fontsize=8)
a2.set_xlabel("Share of spot cargoes loaded inside the Gulf (%)"); a2.set_ylabel("Corridor HHI")
a2.set_title("Sensitivity to spot-origin assumption", color=NAVY, fontweight="bold", fontsize=9.5)
for a in (a1, a2): a.grid(alpha=.3)
panels([a1, a2])
save(fig, "fig_corridor_hhi")

IND = {  # normalised indicator values (1 = most vulnerable); q = qualitative expert score
 "Availability":  [("Primary-energy import dependence", 0.625, "D"), ("Domestic gas decline", 0.80, "q")],
 "Accessibility": [("Share of LNG via Hormuz", p["lng_hormuz"], "D"), ("LNG supplier HHI", (OUT["diversity"]["suppliers"]["HHI"]-.1)/.9, "D"),
                   ("LNG corridor HHI", (OUT["diversity"]["corr"]["HHI"]-.1)/.9, "D")],
 "Affordability": [("Spot-price spike, Jan-Mar 2026", 1.83/3.0, "D"), ("Generation-cost rise over four years", .83/1.5, "D"), ("Foreign-exchange exposure", 0.75, "q")],
 "Acceptability": [("Fossil share of capacity", (0.95-.3)/.7, "D"), ("Coal share of capacity", 0.24/0.5, "D")],
}
Vd = {d: float(np.mean([v for _, v, _ in L])) for d, L in IND.items()}
V_eq = float(np.mean(list(Vd.values())))
allv = [v for L in IND.values() for _, v, _ in L]; V_ind = float(np.mean(allv))
w = rng.dirichlet(np.ones(4), 10000); Vr = w @ np.array(list(Vd.values()))
loo = {d: float(np.mean([Vd[k] for k in Vd if k != d])) for d in Vd}
Vd_noq = {d: float(np.mean([v for _, v, s in L if s != "q"])) for d, L in IND.items()}
OUT["fourA"] = dict(Vd=Vd, V_equal=V_eq, V_indicator_equal=V_ind, V_random_weights=[float(np.percentile(Vr, q)) for q in (5, 50, 95)],
                    V_leave_one_out=loo, V_no_qualitative=float(np.mean(list(Vd_noq.values()))),
                    indicators={d: [(n, round(v, 3), s) for n, v, s in L] for d, L in IND.items()})
dims = list(Vd.keys()); vals = list(Vd.values()) + [list(Vd.values())[0]]
ang = np.linspace(0, 2*np.pi, len(dims), endpoint=False).tolist(); ang += ang[:1]
fig = plt.figure(figsize=(4.6, 4.6)); ax = plt.subplot(111, polar=True)
ax.plot(ang, vals, color=RED, lw=2); ax.fill(ang, vals, color=RED, alpha=.2)
ax.set_xticks(ang[:-1]); ax.set_xticklabels(dims, fontsize=9); ax.set_ylim(0, 1)
ax.set_title(f"Four-A diagnostic profile (V = {V_eq:.2f})", color=NAVY, fontweight="bold", pad=18)
save(fig, "fig_radar")

# =====================================================================================
# 11. Validation against observed operating data (Section 7.1, Appendix D)
# =====================================================================================
import validation as V
gchk = V.gas_check()
d_fit = V.fit_delta()                       # fitted on the April 2026 cases
rows0, ns0 = V.hindcast(delta=0.0)
rows1, ns1 = V.hindcast(delta=d_fit)
loo = []
for k in range(1, 6):
    dk = V.fit_delta(idx=tuple(i for i in range(1, 6) if i != k))
    loo.append(dict(case=V.CASES[k]["id"], delta=dk, pred=V.hindcast(delta=dk)[0][k]["pred"], obs=V.CASES[k]["obs"]))
loo_err = np.array([abs(r["pred"] - r["obs"]) for r in loo]); loo_obs = np.array([r["obs"] for r in loo])
OUT["validation"] = dict(
    gas=gchk, delta_fit=d_fit,
    cases=[dict(id=r["id"], demand=r["demand"], obs=r["obs"], pred_reported=r0["pred"], pred_calibrated=r["pred"], src=r["src"])
           for r0, r in zip(rows0, rows1)],
    noshed_pred_reported=[x["pred"] for x in ns0], noshed_pred_calibrated=[x["pred"] for x in ns1], noshed_demand=V.NOSHED,
    metrics_reported_crisis=V.metrics(rows0[1:]), metrics_train=V.metrics([rows1[i] for i in V.TRAIN]),
    metrics_test=V.metrics([rows1[i] for i in V.TEST]),
    loo=loo, loo_MAE=float(loo_err.mean()), loo_MAPE=float((loo_err / loo_obs).mean() * 100),
    loo_delta_range=[min(r["delta"] for r in loo), max(r["delta"] for r in loo)])
fig, axs = plt.subplots(1, 2, figsize=(10.8, 4.2))
ax = axs[0]
xs = np.linspace(600, 1000, 10)
ax.plot(xs, V.MW_PER_MMCFD * xs, color=NAVY, lw=2, label=f"Model: {V.MW_PER_MMCFD} MW per mmcfd")
for pt, g in zip(gchk["points"], V.GAS_OBS):
    yerr = None if g[2] is None else [[g[1] - g[2][0]], [g[2][1] - g[1]]]
    ax.errorbar(pt["mmcfd"], pt["obs"], yerr=yerr, fmt="o", color=RED, ms=6, capsize=3)
ax.plot([], [], "o", color=RED, label="Observed (BPDB/Petrobangla, as reported)")
ax.set_xlabel("Gas supplied to power plants (mmcfd)"); ax.set_ylabel("Gas-fired generation (MW)")
ax.set_title(f"Gas-to-power conversion (MAPE {gchk['MAPE']:.1f}%, n = {len(V.GAS_OBS)})", color=NAVY, fontweight="bold", fontsize=9.5)
ax.legend(fontsize=7.8, loc="upper left"); ax.grid(alpha=.3)
ax = axs[1]
lim = 5000
ax.plot([0, lim], [0, lim], color="k", lw=1); ax.fill_between([0, lim], [0, 0.75 * lim], [0, 1.25 * lim], color=GREY, alpha=.12, label="±25%")
o = np.array([r["obs"] for r in rows1]); q0 = np.array([r["pred"] for r in rows0]); q1 = np.array([r["pred"] for r in rows1])
ax.scatter(o[1:], q0[1:], marker="o", facecolors="none", edgecolors=BLUE, s=45, label="Crisis hours, planned availability + reported outages")
ax.scatter(o[V.TRAIN, ], q1[list(V.TRAIN)], marker="s", color=AMBER, s=40, label=f"Crisis hours, calibrated (fit, Apr 2026; δ = {d_fit:.2f})")
ax.scatter(o[list(V.TEST)], q1[list(V.TEST)], marker="D", color=RED, s=40, label="Crisis hours, calibrated (independent test, Aug 2026)")
ax.scatter([o[0]], [q1[0]], marker="^", color=GREEN, s=55, label="Pre-crisis peak, 12 Jul 2025")
ax.scatter(np.zeros(len(ns1)), [x["pred"] for x in ns1], marker="x", color=GREEN, s=40, label="7 days with demand fully met, Apr-May 2026")
ax.set_xlim(-150, lim); ax.set_ylim(-150, lim)
ax.set_xlabel("Observed shortfall (MW)"); ax.set_ylabel("Model shortfall (MW)")
ax.set_title("Hindcast of observed load-shedding", color=NAVY, fontweight="bold", fontsize=9.5)
ax.grid(alpha=.3)
panels(axs)
h_, l_ = axs[1].get_legend_handles_labels()
fig.legend(h_, l_, fontsize=7.6, ncol=3, loc="lower center", bbox_to_anchor=(0.5, -0.13))
save(fig, "fig_validation")

# headline results at the calibrated (observed 2026) availability
calib = {}
for dlt in (d_fit, OUT["validation"]["loo_delta_range"][0]):
    q = m.P({"af_coal": p["af_coal"] * (1 - dlt), "af_hfo": p["af_hfo"] * (1 - dlt),
             "af_hsd": p["af_hsd"] * (1 - dlt), "af_imp": p["af_imp"] * (1 - dlt)})
    B60, mm60, u60, s60 = m.bias(q, 60); B30, _, u30, s30 = m.bias(q, 30)
    calib[f"{dlt:.3f}"] = dict(delta=dlt, dU60=u60 / 1e3, B30=B30 * 100, B60=B60 * 100,
                               mal60_ratio=m.attributable(q, "Malacca_Sunda", 60) / u60,
                               mal90_ratio=m.attributable(q, "Malacca_Sunda", 90) / m.attributable(q, "Hormuz", 90),
                               ref_EUE=m.dispatch_day(q, None, 0) / 1e3)
OUT["calibrated_availability"] = calib

# =====================================================================================
# 12. Operational constraints and network (Section 7.6, Table ops)
# =====================================================================================
ops_cfgs = [
    ("baseline", "Single node, no operating constraints (baseline)", dict(reserve=False, ramping=False, losses=False, zones=False)),
    ("reserve", "Spinning reserve, max(660 MW, 5% of demand)", dict(reserve=True, ramping=False, losses=False, zones=False)),
    ("ramp", "Ramp limits and minimum stable output", dict(reserve=False, ramping=True, losses=False, zones=False)),
    ("loss", "Transmission losses, 3%", dict(reserve=False, ramping=False, losses=True, zones=False)),
    ("zones3000", "Two zones, east-west transfer 3,000 MW", dict(reserve=False, ramping=False, losses=False, zones=True, ops={"transfer": 3000})),
    ("all3000", "All of the above, transfer 3,000 MW", dict(ops={"transfer": 3000})),
    ("all1000", "All of the above, transfer 1,000 MW", dict(ops={"transfer": 1000})),
    ("all500", "All of the above, transfer 500 MW", dict(ops={"transfer": 500})),
    ("all_res10", "All, reserve 10% of demand, transfer 1,000 MW", dict(ops={"transfer": 1000, "reserve_frac": 0.10})),
]
ops_res = {}
for key, lab, kw in ops_cfgs:
    um = m.attributable_ops(p, "Hormuz", 60, **kw); us = m.attributable_ops(p, "Hormuz", 60, lng_only=True, **kw)
    um30 = m.attributable_ops(p, "Hormuz", 30, **kw); us30 = m.attributable_ops(p, "Hormuz", 30, lng_only=True, **kw)
    ml60 = m.attributable_ops(p, "Malacca_Sunda", 60, **kw)
    ml90 = m.attributable_ops(p, "Malacca_Sunda", 90, **kw); h90 = m.attributable_ops(p, "Hormuz", 90, **kw)
    ops_res[key] = dict(label=lab, ref_EUE=m.day_lp_ops(p, None, 0, **kw) / 1e3, dU60=um / 1e3,
                        B30=(um30 - us30) / us30 * 100, B60=(um - us) / us * 100, mal60=ml60 / um, mal90=ml90 / h90)
OUT["ops"] = ops_res

# =====================================================================================
# 13. Two-dimensional sensitivity sweeps (Section 7.6)
# =====================================================================================
hb = np.arange(10, 41, 5); oh = np.round(np.arange(0.40, 0.91, 0.05), 2)
Z1 = np.array([[m.bias(m.P({"buf_hfo": b, "buf_hsd": b - 3, "oil_hormuz": s_}), 60)[0] * 100 for b in hb] for s_ in oh])
cb = np.arange(15, 61, 5); cm = np.round(np.arange(0.60, 1.001, 0.05), 2)
Z2 = np.array([[m.attributable(m.P({"buf_coal": b, "coal_malacca": s_}), "Malacca_Sunda", 60) /
                m.attributable(m.P({"buf_coal": b, "coal_malacca": s_}), "Hormuz", 60) for b in cb] for s_ in cm])
OUT["sweep2d"] = dict(hfo_buf=hb.tolist(), oil_hormuz=oh.tolist(), B60=Z1.tolist(), B60_min=float(Z1.min()), B60_max=float(Z1.max()),
                      coal_buf=cb.tolist(), coal_malacca=cm.tolist(), ratio60=Z2.tolist(), ratio_min=float(Z2.min()), ratio_max=float(Z2.max()))
fig, axs = plt.subplots(1, 2, figsize=(10.8, 4.0))
for ax, Z, xv, yv, xl, yl, ttl, lev, cmap, fmt, star in [
        (axs[0], Z1, hb, oh, "HFO buffer (days; HSD = HFO - 3)", "Share of oil products via Hormuz", "Single-fuel understatement B(60), %",
         [100, 200, 300, 400, 500], "Reds", "%d", (p["buf_hfo"], p["oil_hormuz"])),
        (axs[1], Z2, cb, cm, "Coal buffer (days)", "Share of imported coal via Malacca/Sunda", "Malacca/Hormuz consequence ratio, 60 d",
         [0.25, 0.5, 0.75, 1.0], "Blues", "%.2f", (p["buf_coal"], p["coal_malacca"]))]:
    pc = ax.pcolormesh(xv, yv, Z, cmap=cmap, shading="nearest")
    cs = ax.contour(xv, yv, Z, levels=lev, colors="k", linewidths=0.8); ax.clabel(cs, fmt=fmt, fontsize=7.5)
    ax.plot(*star, marker="*", color="gold", mec="k", ms=13, label="baseline")
    fig.colorbar(pc, ax=ax, fraction=0.046, pad=0.03)
    ax.set_xlabel(xl); ax.set_ylabel(yl); ax.set_title(ttl, color=NAVY, fontweight="bold", fontsize=9.5); ax.legend(fontsize=7.5, loc="lower right")
panels(axs)
save(fig, "fig_sweep2d")

OUT["runtime_s"] = time.time() - T0
json.dump(OUT, open("manuscript_numbers.json", "w"), indent=1, default=float)
print(json.dumps({k: OUT[k] for k in ["calibration", "bias_modelA", "corridors_modelA", "base_metrics"]}, indent=1, default=float))
print("runtime", OUT["runtime_s"])
