# Supplementary code: EGYR-S-26-04800 (second revision)

Corridor-exposure and fuel-constrained dispatch model for Bangladesh, as used in
"Multi-Corridor Chokepoint Exposure and Energy Security in Bangladesh".

## Files
- `corridor_model.py`: the model. `PARAMS` holds every parameter with value, unit,
  status (M/D/E/A), source and sensitivity range (Table 6 of the paper).
  - `availability()`: Eq. (2), availability-cap formulation (Model A).
  - `dispatch_day()`: daily dispatch (merit order, exact LP optimum without storage).
  - `day_lp_storage()`: hourly LP with battery state of charge (Eqs. C.4-C.6).
  - `inventory_myopic()` / `inventory_lp()`: explicit fuel-inventory Model B (Eq. 3 and
    Eqs. C.7-C.9), myopic or perfect-foresight rationing, fixed or flexible residual supply.
  - `day_lp_ops()`: extended daily LP with spinning reserve, ramp limits, minimum stable
    output, transmission losses and a stylised two-zone network (Eqs. C.10-C.12).
  - `bias()`: single-fuel bias B(D), Eq. (4), on closure-attributable unserved energy.
- `validation.py`: comparison with observed 2025-2026 operating data (Section 7.1,
  Appendix D): gas-to-power conversion, hindcast of dated load-shedding, outage derate
  fitted on April 2026 and tested on August 2026, leave-one-out check.
- `run_revision.py`: runs every experiment and writes all figures to `figs/`
  and all reported numbers to `manuscript_numbers.json`.
- `manuscript_numbers.json`: the output used in the paper.

## Run
    pip install numpy scipy matplotlib
    python run_revision.py

This takes about one minute on a laptop (SciPy >= 1.9 with the HiGHS solver).
The Latin-hypercube and Monte Carlo seeds are fixed, so the results are reproducible.
