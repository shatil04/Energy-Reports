"""
corridor_model.py  --  Corridor-exposure / fuel-constrained dispatch model for Bangladesh
==========================================================================================
Model code for the manuscript "Multi-Corridor Chokepoint Exposure and Energy Security
in Bangladesh" (Energy Reports, EGYR-S-26-04800, revised version).

Two formulations of the same system are implemented:

  Model A  (availability-cap formulation, Eq. 2 of the paper; baseline)
      Closure of corridor c scales the hourly capacity of every unit whose fuel is
      exposed to c.  Each day is an independent 24-hour linear programme.  Without
      storage the LP is solved exactly by merit order, which is what `dispatch_day`
      does (it is verified against the LP in `verify_lp_equivalence`).

  Model B  (explicit fuel-inventory formulation, Appendix C, Eqs. C.7-C.9)
      Fuel stocks are tracked explicitly.  The initial stock of an exposed fuel is
      beta_f * r_f * F_f, where F_f is its normal daily consumption.  Residual deliveries
      through open corridors are either fixed at (1 - r_f) F_f or flexible up to the
      capacity-equivalent rate.  The operator is either myopic (`inventory_myopic`) or
      rations with perfect foresight over the whole closure (`inventory_lp`).
      Neither formulation is a strict bound: for a Hormuz closure Model B gives MORE
      unserved energy than Model A, because the oil fleet runs harder once LNG is lost
      and exhausts its stocks sooner; for a Malacca/Sunda closure, foresight rationing
      of coal stocks gives LESS.

Fuel quantities are measured in MWh of electricity (constant heat rate per technology).
All parameters are collected in PARAMS with their source, status and sensitivity range.
Requires numpy, scipy (>=1.9, HiGHS), matplotlib.
"""
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import lil_matrix

HOURS = 24

# ------------------------------------------------------------------------------------
# PARAMETERS  (value, unit, status, source/justification, sensitivity range)
# status: M = measured, D = derived from measured data, E = estimated, A = assumed
# ------------------------------------------------------------------------------------
PARAMS = {
    # ---- deliverable capacity by technology (MW) ----
    "cap_domgas": (3000.0, "MW", "D", "Gas-to-power ~870 mmcfd before closure x ~5.6 MW per mmcfd (BPDB summer-2026 plan: 800 mmcfd -> <4,500 MW); domestic share ~61% of national gas supply", (2600, 3400)),
    "cap_lng":    (1900.0, "MW", "D", "LNG share of national gas supply ~39% (Petrobangla: 952 of 2,650 mmcfd, Apr 2026) applied to ~4,900 MW gas-fired output", (1500, 2500)),
    "cap_coal":   (6203.0, "MW", "M", "Installed coal capacity, BPDB summer-2026 plan", None),
    "cap_hfo":    (5634.0, "MW", "M", "Installed furnace-oil capacity, BPDB summer-2026 plan", None),
    "cap_hsd":    (606.0,  "MW", "M", "Installed diesel capacity, BPDB/SREDA Aug 2025", None),
    "cap_imp":    (2696.0, "MW", "M", "Cross-border import capacity (Bheramara HVDC, Tripura, Adani Godda), BPDB/SREDA", None),
    "cap_hydro":  (230.0,  "MW", "M", "Kaptai hydro, SREDA 2025", None),
    "cap_wind":   (61.0,   "MW", "M", "On-grid wind, SREDA 2025", None),
    "cap_solar":  (1024.0, "MW", "D", "On-grid solar = renewable total 1,315 MW less hydro and wind (Table 2)", None),
    # ---- technical availability factors ----
    "af_coal":  (0.92, "-", "D", "BPDB expects ~5,700 MW from 6,203 MW (summer-2026 plan)", (0.72, 0.95)),
    "af_hfo":   (0.62, "-", "D", "BPDB expects ~3,500 MW from 5,634 MW (summer-2026 plan)", (0.45, 0.75)),
    "af_hsd":   (0.55, "-", "E", "Peaking fleet, derated", (0.40, 0.70)),
    "af_imp":   (0.85, "-", "E", "Historical interconnector utilisation", (0.70, 0.95)),
    "af_hydro": (0.70, "-", "E", "Dry-season reservoir limit", (0.50, 0.90)),
    "af_wind":  (0.25, "-", "E", "Coastal wind capacity factor", (0.15, 0.35)),
    # ---- short-run marginal costs (BDT/kWh) ----
    "mc_domgas": (4.0,  "BDT/kWh", "E", "BPDB/IEEFA generation-cost data", (3.0, 5.0)),
    "mc_imp":    (8.5,  "BDT/kWh", "E", "BPDB/IEEFA", (7.0, 10.0)),
    "mc_coal":   (9.0,  "BDT/kWh", "E", "BPDB/IEEFA", (7.5, 11.0)),
    "mc_lng":    (13.5, "BDT/kWh", "E", "BPDB/IEEFA at pre-crisis LNG prices", (11.0, 30.0)),
    "mc_hfo":    (16.0, "BDT/kWh", "E", "BPDB/IEEFA", (14.0, 22.0)),
    "mc_hsd":    (25.0, "BDT/kWh", "E", "BPDB/IEEFA", (22.0, 35.0)),
    "voll_bdt":  (110.0, "BDT/kWh", "E", "US$900/MWh at ~122 BDT/USD; see VOLL review [Schroeder & Kuckshinrichs 2015]", (60.0, 245.0)),
    # ---- demand ----
    "peak":      (17800.0, "MW", "E", "Summer-2026 planning peak (BPDB projection ~18,000 MW)", (16500, 19000)),
    # ---- exposure matrix ----
    "lng_hormuz":  (0.67, "-", "D", "Qatar 36.3% + ~69% of spot cargoes loaded inside the Gulf (Petrobangla 2025 cargo data; EIA 2024)", (0.55, 0.86)),
    "lng_oman":    (0.19, "-", "M", "Oman OQ 19.1% of 2025 LNG energy (Petrobangla)", None),
    "coal_import": (0.915, "-", "D", "Barapukuria (525 MW, domestic coal) is ~8.5% of coal capacity", (0.88, 0.95)),
    "coal_malacca":(0.88, "-", "D", "Indonesia 6.6 of 7.5 Mt coal imports (2022); remainder Australia/S. Africa", (0.70, 0.95)),
    "oil_hormuz":  (0.70, "-", "E", "Gulf-sourced share of HFO/HSD (BPC crude and product sourcing)", (0.50, 0.85)),
    # ---- buffers (days of cover of the interrupted flow) ----
    "buf_lng":  (6.0,  "d", "D", "Two FSRUs of 138,000 m3 (~2.9 bcf each) vs ~1,000 mmcfd send-out", (3, 10)),
    "buf_coal": (35.0, "d", "E", "Plant coal-yard design cover", (20, 50)),
    "buf_hfo":  (25.0, "d", "E", "IPP tank stocks plus BPC depot cover", (15, 35)),
    "buf_hsd":  (22.0, "d", "E", "BPC depot cover", (12, 32)),
    "tau":      (7.0,  "d", "A", "Spread of stock-exhaustion dates across plants/terminals (Model A only)", (0, 21)),
}

def P(params=None):
    """Return a flat dict of central values, optionally overridden."""
    d = {k: v[0] for k, v in PARAMS.items()}
    if params: d.update(params)
    return d

# Normalised daily load shape (fraction of peak) and solar capacity factor
LOAD_SHAPE = np.array([0.72,0.70,0.69,0.70,0.72,0.74,0.76,0.80,0.84,0.87,0.88,0.89,
                       0.88,0.87,0.86,0.86,0.87,0.90,0.95,0.99,1.00,1.00,0.92,0.80])
SOLAR_CF   = np.array([0,0,0,0,0,0,0.05,0.15,0.30,0.45,0.58,0.66,0.70,0.66,0.58,
                       0.45,0.30,0.15,0.05,0,0,0,0,0])

FUELS = ["DomGas","LNG","Coal","HFO","HSD","Import","Hydro","Wind"]
CORRIDORS = ["Hormuz","GulfOfOman","Atlantic","Malacca_Sunda","OtherCoal","OtherOil","Transmission"]

def fleet(p):
    """Return {unit: (available MW before closure, marginal cost BDT/kWh)}."""
    return {
        "DomGas": (p["cap_domgas"],                 p["mc_domgas"]),
        "LNG":    (p["cap_lng"],                    p["mc_lng"]),
        "Coal":   (p["cap_coal"]*p["af_coal"],      p["mc_coal"]),
        "HFO":    (p["cap_hfo"]*p["af_hfo"],        p["mc_hfo"]),
        "HSD":    (p["cap_hsd"]*p["af_hsd"],        p["mc_hsd"]),
        "Import": (p["cap_imp"]*p["af_imp"],        p["mc_imp"]),
        "Hydro":  (p["cap_hydro"]*p["af_hydro"],    0.0),
        "Wind":   (p["cap_wind"]*p["af_wind"],      0.0),
    }

def exposure(p):
    """Exposure matrix: {fuel: (import share iota, {corridor: rho}, buffer beta)}."""
    lng_atl = max(0.0, 1.0 - p["lng_hormuz"] - p["lng_oman"])
    lng_oman = min(p["lng_oman"], 1.0 - p["lng_hormuz"])
    return {
        "DomGas": (0.0, {}, 0.0),
        "LNG":    (1.0, {"Hormuz": p["lng_hormuz"], "GulfOfOman": lng_oman, "Atlantic": lng_atl}, p["buf_lng"]),
        "Coal":   (p["coal_import"], {"Malacca_Sunda": p["coal_malacca"], "OtherCoal": 1-p["coal_malacca"]}, p["buf_coal"]),
        "HFO":    (1.0, {"Hormuz": p["oil_hormuz"], "OtherOil": 1-p["oil_hormuz"]}, p["buf_hfo"]),
        "HSD":    (1.0, {"Hormuz": p["oil_hormuz"], "OtherOil": 1-p["oil_hormuz"]}, p["buf_hsd"]),
        "Import": (1.0, {"Transmission": 1.0}, 0.0),
        "Hydro":  (0.0, {}, 0.0),
        "Wind":   (0.0, {}, 0.0),
    }

def at_risk(p, fuel, corridor):
    iota, rho, _ = exposure(p)[fuel]
    return iota * rho.get(corridor, 0.0)

def availability(p, fuel, corridor, t, tau=None, reroute=None):
    """Eq. (2): a_f(c,t) = 1 - r_{f,c} * min(1, max(0, (t - beta_f)/tau)).
    tau = 0 gives a step at t = beta_f.  Optional rerouting recovers a share theta of the
    lost supply, ramping in linearly over 7 days after a lag of L days."""
    if corridor is None: return 1.0
    r = at_risk(p, fuel, corridor)
    if r <= 0: return 1.0
    beta = exposure(p)[fuel][2]
    tau = p["tau"] if tau is None else tau
    if tau <= 0: g = 1.0 if t >= beta else 0.0
    else:        g = min(1.0, max(0.0, (t - beta) / tau))
    if reroute and fuel in reroute.get("fuels", []):
        rec = reroute["theta"] * min(1.0, max(0.0, (t - reroute["lag"]) / 7.0))
        r = r * (1.0 - rec)
    return 1.0 - r * g

# ------------------------------------------------------------------------------------
# Model A: one day, merit order (exact LP solution without storage)
# ------------------------------------------------------------------------------------
def dispatch_day(p, corridor, t, lng_only=False, extra_solar=0.0, dr_evening=0.0, tau=None, reroute=None, return_detail=False):
    fl = fleet(p)
    caps, costs, names = [], [], []
    for f, (mw, mc) in fl.items():
        if lng_only: a = availability(p, f, corridor, t, tau, reroute) if f == "LNG" else 1.0
        else:        a = availability(p, f, corridor, t, tau, reroute)
        caps.append(mw * a); costs.append(mc); names.append(f)
    order = np.argsort(costs, kind="stable")
    demand = LOAD_SHAPE * p["peak"]
    if dr_evening > 0: demand = demand - dr_evening * (np.arange(24) >= 18) * (np.arange(24) <= 22)
    solar = (p["cap_solar"] + extra_solar) * SOLAR_CF
    resid = np.maximum(0.0, demand - solar)
    gen = np.zeros((len(names), HOURS))
    for i in order:
        g = np.minimum(caps[i], resid); gen[i] = g; resid = resid - g
    u = np.maximum(0.0, resid)
    if return_detail:
        return dict(unserved=u, gen={n: gen[k] for k, n in enumerate(names)}, solar=np.minimum(solar, demand), demand=demand)
    return float(u.sum())

def cumulative_eue(p, corridor, D, lng_only=False, **kw):
    """Cumulative unserved energy (MWh) over days 0..D-1 of a closure."""
    return sum(dispatch_day(p, corridor, t, lng_only=lng_only, **kw) for t in range(D))

def attributable(p, corridor, D, lng_only=False, **kw):
    """Closure-attributable unserved energy: cumulative EUE minus the no-closure reference."""
    ref = D * dispatch_day(p, None, 0, **{k: v for k, v in kw.items() if k in ("extra_solar","dr_evening")})
    return cumulative_eue(p, corridor, D, lng_only, **kw) - ref

def bias(p, D, corridor="Hormuz", **kw):
    """Single-fuel understatement B(D) = (dU_multi - dU_single)/dU_single, and share missed m(D)."""
    um = attributable(p, corridor, D, **kw); us = attributable(p, corridor, D, lng_only=True, **kw)
    B = (um - us) / us if us > 0 else 0.0
    m = (um - us) / um if um > 0 else 0.0
    return B, m, um, us

# ------------------------------------------------------------------------------------
# Hourly LP for one day with a battery (explicit state of charge)
# ------------------------------------------------------------------------------------
def day_lp_storage(p, corridor, t, E, P_ratio=4.0, eta_rt=0.88, extra_solar=0.0, lng_only=False, usable=1.0):
    """Minimise sum_h [sum_g c_g p_gh + VOLL u_h] with battery SOC dynamics.
    Variables per hour: p_g (8 units), solar used, charge, discharge, soc, u.
    Returns (unserved MWh, dict)."""
    fl = fleet(p); names = list(fl.keys()); G = len(names)
    Eu = E * usable; Pb = E / P_ratio if E > 0 else 0.0
    ec = ed = np.sqrt(eta_rt)
    nv = HOURS * (G + 5)
    def ix(h, k): return h * (G + 5) + k       # k: 0..G-1 units, G solar, G+1 ch, G+2 dis, G+3 soc, G+4 u
    c = np.zeros(nv); lb = np.zeros(nv); ub = np.zeros(nv)
    demand = LOAD_SHAPE * p["peak"]; solar = (p["cap_solar"] + extra_solar) * SOLAR_CF
    for h in range(HOURS):
        for k, n in enumerate(names):
            mw, mc = fl[n]
            a = (availability(p, n, corridor, t) if (not lng_only or n == "LNG") else 1.0)
            c[ix(h,k)] = mc; ub[ix(h,k)] = mw * a
        ub[ix(h,G)] = solar[h]
        ub[ix(h,G+1)] = Pb; ub[ix(h,G+2)] = Pb; ub[ix(h,G+3)] = Eu
        c[ix(h,G+4)] = p["voll_bdt"]; ub[ix(h,G+4)] = demand[h]
        c[ix(h,G+1)] = 1e-3          # tiny wear cost avoids spurious simultaneous cycling
    Aeq = lil_matrix((2 * HOURS, nv)); beq = np.zeros(2 * HOURS)
    for h in range(HOURS):
        for k in range(G + 1): Aeq[h, ix(h,k)] = 1.0
        Aeq[h, ix(h,G+1)] = -1.0; Aeq[h, ix(h,G+2)] = 1.0; Aeq[h, ix(h,G+4)] = 1.0
        beq[h] = demand[h]
        hp = (h - 1) % HOURS                       # cyclic SOC over the day
        r = HOURS + h
        Aeq[r, ix(h,G+3)] = 1.0; Aeq[r, ix(hp,G+3)] = -1.0
        Aeq[r, ix(h,G+1)] = -ec; Aeq[r, ix(h,G+2)] = 1.0 / ed
    res = linprog(c, A_eq=Aeq.tocsr(), b_eq=beq, bounds=list(zip(lb, ub)), method="highs")
    assert res.status == 0, res.message
    x = res.x
    u = np.array([x[ix(h,G+4)] for h in range(HOURS)])
    soc = np.array([x[ix(h,G+3)] for h in range(HOURS)])
    ch = np.array([x[ix(h,G+1)] for h in range(HOURS)]); dis = np.array([x[ix(h,G+2)] for h in range(HOURS)])
    return float(u.sum()), dict(u=u, soc=soc, ch=ch, dis=dis)

def verify_lp_equivalence(p, corridor="Hormuz", days=(0, 10, 30, 60)):
    """Check that merit-order dispatch equals the LP optimum when there is no storage."""
    out = []
    for t in days:
        a = dispatch_day(p, corridor, t); b, _ = day_lp_storage(p, corridor, t, 0.0)
        out.append((t, a, b))
    return out

# ------------------------------------------------------------------------------------
# Model B: explicit inventory, perfect-foresight rationing over the closure horizon
# ------------------------------------------------------------------------------------
def inventory_lp(p, corridor, D, lng_only=False, supply="fixed"):
    """Model B, perfect-foresight operator: cumulative unserved energy (MWh) and daily profile.
    supply="fixed":    deliveries through unaffected corridors stay at normal volumes, (1-r) F_f per day.
    supply="flexible": deliveries through unaffected corridors can rise to the capacity-equivalent
                       rate (1-r) x available MW x 24 h, the supply assumption implicit in Model A.
    In both variants the initial stock is beta_f r_f F_f, i.e. beta_f days of cover of the
    interrupted part of NORMAL consumption, and the operator rations with perfect foresight."""
    fl = fleet(p); names = list(fl.keys()); G = len(names)
    ref = dispatch_day(p, None, 0, return_detail=True)
    F = {n: ref["gen"][n].sum() for n in names}           # normal daily throughput (MWh)
    exp_ = exposure(p)
    r = {n: (at_risk(p, n, corridor) if (not lng_only or n == "LNG") else 0.0) for n in names}
    constrained = [n for n in names if r[n] > 0]
    demand = LOAD_SHAPE * p["peak"]; solar = p["cap_solar"] * SOLAR_CF
    nh = D * HOURS
    nvar_h = G + 1                                         # units + u
    nv = nh * nvar_h
    c = np.zeros(nv); ub = np.zeros(nv)
    def ix(t, h, k): return (t * HOURS + h) * nvar_h + k
    for t in range(D):
        for h in range(HOURS):
            for k, n in enumerate(names):
                c[ix(t,h,k)] = fl[n][1]; ub[ix(t,h,k)] = fl[n][0]
            c[ix(t,h,G)] = p["voll_bdt"]; ub[ix(t,h,G)] = demand[h]
    Aeq = lil_matrix((nh, nv)); beq = np.zeros(nh)
    for t in range(D):
        for h in range(HOURS):
            row = t * HOURS + h
            for k in range(G + 1): Aeq[row, ix(t,h,k)] = 1.0
            beq[row] = max(0.0, demand[h] - solar[h])
    # cumulative fuel constraint: sum_{s<=t} use_s <= S0 + (t+1)*(1-r)F   for each constrained fuel
    rows = []; rhs = []
    for n in constrained:
        k = names.index(n); beta = exp_[n][2]
        S0 = beta * r[n] * F[n]
        A = (1 - r[n]) * (F[n] if supply == "fixed" else fl[n][0] * HOURS)
        for t in range(D):
            rows.append([(ix(s,h,k)) for s in range(t + 1) for h in range(HOURS)])
            rhs.append(S0 + (t + 1) * A)
    Aub = lil_matrix((len(rows), nv))
    for i, cols in enumerate(rows):
        for j in cols: Aub[i, j] = 1.0
    res = linprog(c, A_ub=Aub.tocsr() if rows else None, b_ub=np.array(rhs) if rows else None,
                  A_eq=Aeq.tocsr(), b_eq=beq, bounds=list(zip(np.zeros(nv), ub)), method="highs")
    assert res.status == 0, res.message
    u = res.x[G::nvar_h].reshape(D, HOURS)
    return float(u.sum()), u.sum(axis=1)

def inventory_attributable(p, corridor, D, lng_only=False, supply="fixed"):
    tot, daily = inventory_lp(p, corridor, D, lng_only, supply)
    ref = D * dispatch_day(p, None, 0)
    return tot - ref, daily

# ------------------------------------------------------------------------------------
# Diversity indices
# ------------------------------------------------------------------------------------
def hhi(s):
    s = np.asarray(s, float); s = s / s.sum(); return float((s ** 2).sum())
def shannon(s):
    s = np.asarray(s, float); s = s / s.sum(); s = s[s > 0]; return float(-(s * np.log(s)).sum())

def inventory_myopic(p, corridor, D, lng_only=False, supply="fixed"):
    """Model B, myopic operator: explicit stocks, no knowledge of closure length.
    Each day an hourly LP is solved in which each constrained fuel may use at most the
    fuel on hand that day (stock + arrivals); unused fuel carries over.  Returns cumulative
    unserved energy (MWh) and the daily profile."""
    fl = fleet(p); names = list(fl.keys()); G = len(names)
    ref = dispatch_day(p, None, 0, return_detail=True)
    F = {n: ref["gen"][n].sum() for n in names}
    exp_ = exposure(p)
    r = {n: (at_risk(p, n, corridor) if (not lng_only or n == "LNG") else 0.0) for n in names}
    con = [n for n in names if r[n] > 0]
    stock = {n: exp_[n][2] * r[n] * F[n] for n in con}
    arr = {n: (1 - r[n]) * (F[n] if supply == "fixed" else fl[n][0] * HOURS) for n in con}
    demand = LOAD_SHAPE * p["peak"]; net = np.maximum(0.0, demand - p["cap_solar"] * SOLAR_CF)
    nvh = G + 1; nv = HOURS * nvh
    c = np.zeros(nv); ub = np.zeros(nv)
    for h in range(HOURS):
        for k, n in enumerate(names): c[h*nvh+k] = fl[n][1]; ub[h*nvh+k] = fl[n][0]
        c[h*nvh+G] = p["voll_bdt"]; ub[h*nvh+G] = demand[h]
    Aeq = lil_matrix((HOURS, nv))
    for h in range(HOURS):
        for k in range(G + 1): Aeq[h, h*nvh+k] = 1.0
    Aeq = Aeq.tocsr()
    Aub = lil_matrix((len(con), nv))
    for i, n in enumerate(con):
        k = names.index(n)
        for h in range(HOURS): Aub[i, h*nvh+k] = 1.0
    Aub = Aub.tocsr() if con else None
    daily = []
    for t in range(D):
        onhand = {n: stock[n] + arr[n] for n in con}
        res = linprog(c, A_ub=Aub, b_ub=np.array([onhand[n] for n in con]) if con else None,
                      A_eq=Aeq, b_eq=net, bounds=list(zip(np.zeros(nv), ub)), method="highs")
        assert res.status == 0, res.message
        x = res.x
        for n in con:
            k = names.index(n); used = x[k::nvh].sum()
            stock[n] = max(0.0, onhand[n] - used)
        daily.append(x[G::nvh].sum())
    return float(np.sum(daily)), np.array(daily)

def inventory_myopic_attributable(p, corridor, D, lng_only=False, supply="fixed"):
    tot, daily = inventory_myopic(p, corridor, D, lng_only, supply)
    return tot - D * dispatch_day(p, None, 0), daily
