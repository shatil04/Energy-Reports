# Supplementary code: EGYR-S-26-04800 (Revision 1)

Corridor-exposure and fuel-constrained dispatch model for Bangladesh, as used in
"Multi-Corridor Chokepoint Exposure and Energy Security in Bangladesh".

## Files
- `corridor_model.py`: the model. `PARAMS` holds every parameter with value, unit,
  status (M/D/E/A), source and sensitivity range (Table 5 of the paper).
  - `availability()`: Eq. (2), availability-cap formulation (Model A).
  - `dispatch_day()`: daily dispatch (merit order, exact LP optimum without storage).
  - `day_lp_storage()`: hourly LP with battery state of charge (Eqs. C.4-C.6).
  - `inventory_myopic()` / `inventory_lp()`: explicit fuel-inventory Model B,
    myopic or perfect-foresight rationing, fixed or flexible residual supply (Eqs. C.7-C.9).
  - `bias()`: single-fuel bias B(D), Eq. (3), on closure-attributable unserved energy.
- `run_revision.py`: runs every experiment and writes all figures to `figs/`
  and all reported numbers to `manuscript_numbers.json`.
- `manuscript_numbers.json`: the output used in the paper.

## Run
    pip install numpy scipy matplotlib
    python run_revision.py

This takes about 30 seconds on a laptop (SciPy >= 1.9 with the HiGHS solver).
The Latin-hypercube and Monte Carlo seeds are fixed, so the results are reproducible.
